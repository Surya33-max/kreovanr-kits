# Kreovant Metadata Update

These are metadata-tagged copies of the supplied DaVinci Resolve `.drfx` packages.

- Added a transparent Kreovant library/packager note to editable `.setting` files.
- Preserved existing author names, comments, URLs, and license notices.
- This does not transfer authorship or alter the underlying effects.
- Test each package in DaVinci Resolve before production use.

| File | Original size | Updated size | `.setting` files tagged |
|---|---:|---:|---:|
| `SwiftTransitions.drfx` | 152,773 B | 163,431 B | 71 |
| `ResolveAssets.drfx` | 1,087,115 B | 1,097,687 B | 49 |
| `Multiscreen.drfx` | 1,671,407 B | 1,694,448 B | 62 |
| `LazyCollage.drfx` | 3,386,600 B | 3,513,237 B | 64 |
| `LazyBackgrounds.drfx` | 876,124 B | 884,860 B | 48 |
| `Background Sets.drfx` | 2,304,166 B | 2,343,390 B | 175 |
| `YT.drfx` | 328,092 B | 341,440 B | 57 |
| `3D.drfx` | 336,183 B | 340,557 B | 23 |
| `Gravity.drfx` | 1,720,429 B | 1,771,069 B | 201 |
| `Animated Backgrounds.drfx` | 131,726 B | 132,242 B | 4 |
| `Airwolf.drfx` | 51,895 B | 52,971 B | 1 |
| `VBF- Whip LITE V1.drfx` | 2,520 B | 2,569 B | 1 |
| `Thu4der_WhipRush_1.0.drfx` | 1,871 B | 1,959 B | 1 |
